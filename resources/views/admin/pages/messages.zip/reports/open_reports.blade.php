@extends('admin.app')

@section('content')

<div class="container-fluid">


				<!-- Title -->
				<div class="row heading-bg bg-yellow">
					<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
					  <h5 class="txt-light">Observer Checklist</h5>
					</div>
					<!-- Breadcrumb -->
					<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
					  <ol class="breadcrumb">
						<li><a href="index-2.html">Dashboard</a></li>
						<li><a href="#"><span>Messages</span></a></li>
						<li class="active"><span>Open Messages</span></li>
					  </ol>
					</div>
					<!-- /Breadcrumb -->
				</div>
				<!-- /Title -->
				
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">SMS - 626</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="sm-graph-box">
										<div class="row">
											<div class="col-xs-6">
												<img src="dist/img/magento-sms.png" alt="sms icon" class="img-responsive" />
											</div>
											<div class="col-xs-6">
												<div class="counter-wrap text-right">
													<span class="counter count-block mt-75">125</span>
												</div>	
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">USSD - *6446#</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="sm-graph-box">
										<div class="row">
											<div class="col-xs-6">
												<img src="dist/img/ussd.png" alt="sms icon" class="img-responsive" />
											</div>
											<div class="col-xs-6">
												<div class="counter-wrap text-right">
													<span class="counter count-block mt-75">10</span>
												</div>	
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>

				
				<!-- Row -->
				<div class="row">
					<div class="col-sm-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark">Open Reports</h6>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="table-wrap">
										<div class="table-responsive">
											<table id="example" class="table table-hover display  pb-30" >
												<thead>
													<tr>
														<th>Via Channel</th>
														<th>Sender</th>
														<th>Body</th>
														<th>Time</th>
														<th>Latitude</th>
														<th>Longitude</th>
														<th>Status</th>
														<th>Actions</th>
														<th></th>
													</tr>
												</thead>
												<tfoot>
													<tr>
														<th>Via Channel</th>
														<th>Sender</th>
														<th>Body</th>
														<th>Time</th>
														<th>Latitude</th>
														<th>Longitude</th>
														<th>Status</th>
														<th>Actions</th>
														<th></th>
													</tr>
												</tfoot>
												<tbody class="sms-text-list">




													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
				</div>
				<!-- /Row -->


				
				
			

</div>

@stop


@section('scripts')
	<script type="application/javascript">
		var smsUrl = "{{ url('sms-resources') }}";
        var dataTableScriptVendor = "{{ asset('vendors/bower_components/datatables/media/js/jquery.dataTables.min.js') }}";
        var dataTableScript = "{{ asset('dist/js/dataTables-data.js') }}";
        var fancyDropDownScript = "{{ asset('dist/js/dropdown-bootstrap-extended.js') }}";
        var dtscript1 = "{{ asset('vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js') }}";
	    var dtscript2 = "{{ asset('vendors/bower_components/datatables.net-buttons/js/buttons.flash.min.js') }}";
		var dtscript3 = "{{ asset('vendors/bower_components/jszip/dist/jszip.min.js') }}";
		var dtscript4 = "{{ asset('vendors/bower_components/pdfmake/build/pdfmake.min.js') }}";
		var dtscript5 = "{{ asset('vendors/bower_components/pdfmake/build/vfs_fonts.js') }}";

		var dtscript6 = "{{ asset('vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js') }}";
		var dtscript7 = "{{ asset('vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js') }}";
		var dtscript8 = "{{ asset('dist/js/export-table-data.js') }}";
	</script>


	<script src="vendors/custom_js/open_reports.js"></script>

@stop