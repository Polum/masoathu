<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\ObserverResponse;
use App\ObserverChecklist;
use App\Traits\YesnoTrait;
use App\Traits\MorningTrait;
use App\Traits\AfternoonTrait;
use App\Traits\EveningTrait;

class ObserverResponseController extends Controller
{
    use YesnoTrait, MorningTrait, AfternoonTrait, EveningTrait;

    public function __construct()
    {
        $this->middleware('auth');
        $this->alpha = range('a', 'z');
    }
    
    public function index()
    {
        $data = $this->morning();
        // return $data;
        return view('admin.pages.morning',compact('data'));
    }

    public function morning(){
        return $this->morningTemplate();
    }
    

    public function afternoon()
    {
        $data = $this->afternoonTemplate();
        return view('admin.pages.afternoon',compact('data'));
    }

    public function evening()
    {
        $data =  $this->eveningTemplate();
        return view('admin.pages.evening',compact('data'));
    }

    public function store(Request $request)
    {
        $observerResponse = $request->all();
        $question_no = $this->questionNo($request->text);
        
            
        $question = ObserverChecklist::where('question_no',$question_no)->first();
        if($question){
            $observerResponse["question_id"] = $question->id;
            if(ObserverResponse::create($observerResponse)){
                return response()->json(['status'=>"success", 'data'=>$observerResponse, 'message'=>'success'], 200);
            }
            return response()->json(['status'=>"error", 'data'=>$observerResponse, 'error'=>'error'], 404);
        }
        return response()->json(['status'=>"error", 'data'=>$observerResponse, 'error', 'error 404'], 404);
    }

    public function update(Request $request)
    {
        $message = $request->message;
        $question_no = $this->questionNo($message["text"]);

        $response = ObserverResponse::find($message["id"]);
        foreach($message as $key => $value){
            $response->$key = $message[$key]? $value: $response->$key;
        }

        $question = ObserverChecklist::where('question_no',$question_no)->first();
        $response->question_id = $question->id;
        if($response->save()){
            return Response(['code' => 202, 'data'=>$response, 'message' => 'Message updated succesfully'], 202);
        }
        return Response(['code' => 401, 'message' => 'Failed to update message'], 401);
    }

    public function ontime()
    {
        $data = [];
        $data['ontime'] = 0;
        $data['late'] = 0;
        $observerResponse = ObserverResponse::where('question_id',1)->get();
        foreach($observerResponse as $response){
            $time = substr($response->text, 2);
            $data['ontime'] = ($time <= 730)? $data['ontime']+1 : $data['ontime'];
            $data['late'] = ($time > 730)? $data['late']+1 : $data['late'];
        }
        return $data;
    }

    public function totalECOPresent($qid1, $qid2)
    {
        $data = [];
        $data['male'] = 0;
        $data['female'] = 0;
        $observerResponse = ObserverResponse::where('question_id',$qid1)->orWhere('question_id', $qid2)->get();
        foreach($observerResponse as $response){
            $queue = substr($response->text, 2);
            $data['male'] = (substr($response->text, strpos($response->text, 'a'),1) == 'a')? $data['male']+$queue : $data['male'];
            $data['female'] = (substr($response->text, strpos($response->text, 'b'),1) == 'b')? $data['female']+$queue : $data['female'];
        }
        return $data;
    }

    private function questionNo($data)
    {
        $strArray = explode(';', $data);
        $chars = (sizeOf($strArray) > 1)? $strArray[0]: $data;
        $charArray = str_split($chars);

        foreach($charArray as $letter){
            if(in_array($letter, $this->alpha)){
                $char = $letter;
            }
        }
        $question_no = substr($data, 0, strpos($data, $char)+1);
        return $question_no;
    }

    public function totalPartyRepresentatives()
    {
        $data = [];
        $data['a'] = 0;
        $data['b'] = 0;
        $data['c'] = 0;
        $data['d'] = 0;
        $data['e'] = 0;
        $data['f'] = 0;
        $data['g'] = 0;
        $data['h'] = 0;
        $data['h'] = 0;
        $data['j'] = 0;
        $data['k'] = 0;
        $data['l'] = 0;
        $data['m'] = 0;
        $data['n'] = 0;
        $data['o'] = 0;
        $data['p'] = 0;
        $data['q'] = 0;
        $observerResponse = ObserverResponse::where('question_id',5)
        ->orWhere('question_id', 6)
        ->orWhere('question_id', 7)
        ->orWhere('question_id', 8)
        ->orWhere('question_id', 9)
        ->get();

        foreach($observerResponse as $response){
            $queue = substr($response->text, 2);
            $data['a'] = (substr($response->text, 0, strpos($response->text, 'a')+1) == "2a")? $data['a']+$queue : $data['a'];
            $data['b'] = (substr($response->text, 0, strpos($response->text, 'b')+1) == "2b")? $data['b']+$queue : $data['b'];
            $data['c'] = (substr($response->text, 0, strpos($response->text, 'c')+1) == "2c")? $data['c']+$queue : $data['c'];
            $data['d'] = (substr($response->text, 0, strpos($response->text, 'd')+1) == "2d")? $data['d']+$queue : $data['d'];
            $data['e'] = (substr($response->text, 0, strpos($response->text, 'e')+1) == "2e")? $data['e']+$queue : $data['e'];
            $data['f'] = (substr($response->text, 0, strpos($response->text, 'f')+1) == "2f")? $data['f']+$queue : $data['f'];
        }
        return $data;
    }


    public function responses()
    {
        $responses = ObserverResponse::where('region_id', Auth::user()->region_id)->where('status', '=', null)->get();
        return $responses;
    }

    public function flag(Request $request)
    {
        $request = $request->all();
        $id = $request['flagged']['id'];
        $observerResponse = ObserverResponse::find($id);
        $observerResponse['status'] = 'flagged';
        $observerResponse->save();
        return $observerResponse;
    }

    public function flagged()
    {
        $responses = ObserverResponse::where('region_id', Auth::user()->region_id)->where('status', 'flagged')->get();
        return $responses;
    }

    public function resolve(Request $request)
    {
        $request = $request->all();
        $id = $request['resolving']['id'];
        $observerResponse = ObserverResponse::find($id);
        $observerResponse['status'] = 'resolving';
        $observerResponse->save();
        return $observerResponse;
    }

    public function resolving()
    {
        $responses = ObserverResponse::where('region_id', Auth::user()->region_id)->where('status', 'resolving')->get();
        return $responses;
    }

    public function resolved(Request $request)
    {
        $request = $request->all();
        $id = $request['resolved']['id'];
        $observerResponse = ObserverResponse::find($id);
        $observerResponse['status'] = 'resolved';
        $observerResponse->save();
        return $observerResponse;
    }

    public function completed()
    {
        $responses = ObserverResponse::where('region_id', Auth::user()->region_id)->where('status', 'resolved')->get();
        return $responses;
    }

}
