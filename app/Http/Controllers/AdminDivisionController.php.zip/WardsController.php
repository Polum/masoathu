<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Ward;
use App\Http\Resources\WardsResource;
use DB;

class WardsController extends Controller
{
    public function index()
    {
        $wards = Ward::orderBy('id','asc')->paginate(10);
        //$wards = Ward::all();
        return WardsResource::collection($wards);
    } 
    public function indexAll()
    { 
        $wards = Ward::all();
        return WardsResource::collection($wards);
    }
    public function listAll()
    { 
        $wards = Ward::all();
        return $wards;
    }
    public function show($id)
    {
        $ward = Ward::findOrFail($id);
        return new WardsResource($ward);
    }
}
