<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\District;
use App\Http\Resources\DistrictsResource;
use DB;


class DistrictsController extends Controller
{ 
    public function index()
    {
        $districts = District::orderBy('id','asc')->paginate(10);
        //$districts = District::all();
        return DistrictsResource::collection($districts);
    } 
    public function indexAll()
    { 
        $districts = District::all();
        return DistrictsResource::collection($districts);
    }
    public function listAll()
    {
        $districts = District::all();
        return $districts;
    }
    public function show($id)
    {
        $district = District::findOrFail($id);
        return new DistrictsResource($district);
    }
}
