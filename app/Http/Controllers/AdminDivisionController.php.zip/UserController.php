<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 2018-10-19
 * Time: 4:29 AM
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use App\User;

class UserController extends Controller
{
    /**
     * function to collect all users from te db and list them.
     * @return User[]|\Illuminate\Database\Eloquent\Collection
     */
    function index()
    {
        return User::all();
    }

    public function editUser($id)
    {
        $user = User::find($id);
        // return view('auth.edit', compact('user'));
        return redirect('edit-user')->with( ['user' => $user] );
    }


    public function updateUser(Request $request)
    {
        $user = User::find($request->id);
        $user['id'] = $request->id;
        $user['name'] = $request->name;
        $user['email'] = $request->email;
        $user['password'] = bcrypt($request->password);
        $user['user_type'] = $request->user_type;
        $user['region_id'] = $request->region_id;

        if($user->save()){
            return redirect('users');
        }

        return $user;
    }
}