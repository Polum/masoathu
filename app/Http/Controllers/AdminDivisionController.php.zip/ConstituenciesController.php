<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Constituency;
use App\Http\Resources\ConstituenciesResource;
use DB;

class ConstituenciesController extends Controller
{
    public function index()
    {
        $constituencies = Constituency::orderBy('id','asc')->paginate(10);
        //$constituencies = Constituency::all();
        return ConstituenciesResource::collection($constituencies);
    } 
    public function indexAll()
    { 
        $constituencies = Constituency::all();
        return ConstituenciesResource::collection($constituencies);
    }
    public function listAll()
    { 
        $constituencies = Constituency::all();
        return $constituencies;
    }
    public function show($id)
    {
        $constituency = Constituency::findOrFail($id);
        return new ConstituenciesResource($constituency);
    }
}
